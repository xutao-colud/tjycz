# 天健悦成长 App 工程

此包包含iOS、Android工程及开发模式Web资源。先安装Node依赖，按APP.md设置实际服务地址、构建并同步，再使用完整Xcode或Android Studio编译签名。ZIP不是可直接安装的APK或IPA。

本版：精简老师/家长首页，加入拍照考勤、站内消息、增加课时、照片录题、错题PDF、固定积分与奖品兑换。后端需V17。OCR与微信订阅尚未接入，二维码仍为线下收款。

详细入口与验收范围见 docs/teacher-tools-and-focused-home-acceptance-20261029.md。
